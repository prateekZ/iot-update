package com.montage.connect.domain;

import jakarta.persistence.*;
import java.io.Serializable;
import java.time.Instant;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A DeviceConfigUpdate.
 */
@Entity
@Table(name = "device_config_update")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class DeviceConfigUpdate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "config_version")
    private String configVersion;

    @Column(name = "firmware_version")
    private String firmwareVersion;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "device_id")
    private String deviceId;

    @Lob
    @Column(name = "binary_file")
    private byte[] binaryFile;

    @Column(name = "binary_file_content_type")
    private String binaryFileContentType;

    @Column(name = "date_time")
    private Instant dateTime;

    @Column(name = "customer_id")
    private String customerId;

    @Column(name = "group_id")
    private String groupID;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public DeviceConfigUpdate id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getConfigVersion() {
        return this.configVersion;
    }

    public DeviceConfigUpdate configVersion(String configVersion) {
        this.setConfigVersion(configVersion);
        return this;
    }

    public void setConfigVersion(String configVersion) {
        this.configVersion = configVersion;
    }

    public String getFirmwareVersion() {
        return this.firmwareVersion;
    }

    public DeviceConfigUpdate firmwareVersion(String firmwareVersion) {
        this.setFirmwareVersion(firmwareVersion);
        return this;
    }

    public void setFirmwareVersion(String firmwareVersion) {
        this.firmwareVersion = firmwareVersion;
    }

    public String getFileName() {
        return this.fileName;
    }

    public DeviceConfigUpdate fileName(String fileName) {
        this.setFileName(fileName);
        return this;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getDeviceId() {
        return this.deviceId;
    }

    public DeviceConfigUpdate deviceId(String deviceId) {
        this.setDeviceId(deviceId);
        return this;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public byte[] getBinaryFile() {
        return this.binaryFile;
    }

    public DeviceConfigUpdate binaryFile(byte[] binaryFile) {
        this.setBinaryFile(binaryFile);
        return this;
    }

    public void setBinaryFile(byte[] binaryFile) {
        this.binaryFile = binaryFile;
    }

    public String getBinaryFileContentType() {
        return this.binaryFileContentType;
    }

    public DeviceConfigUpdate binaryFileContentType(String binaryFileContentType) {
        this.binaryFileContentType = binaryFileContentType;
        return this;
    }

    public void setBinaryFileContentType(String binaryFileContentType) {
        this.binaryFileContentType = binaryFileContentType;
    }

    public Instant getDateTime() {
        return this.dateTime;
    }

    public DeviceConfigUpdate dateTime(Instant dateTime) {
        this.setDateTime(dateTime);
        return this;
    }

    public void setDateTime(Instant dateTime) {
        this.dateTime = dateTime;
    }

    public String getCustomerId() {
        return this.customerId;
    }

    public DeviceConfigUpdate customerId(String customerId) {
        this.setCustomerId(customerId);
        return this;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getGroupID() {
        return this.groupID;
    }

    public DeviceConfigUpdate groupID(String groupID) {
        this.setGroupID(groupID);
        return this;
    }

    public void setGroupID(String groupID) {
        this.groupID = groupID;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof DeviceConfigUpdate)) {
            return false;
        }
        return getId() != null && getId().equals(((DeviceConfigUpdate) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "DeviceConfigUpdate{" +
            "id=" + getId() +
            ", configVersion='" + getConfigVersion() + "'" +
            ", firmwareVersion='" + getFirmwareVersion() + "'" +
            ", fileName='" + getFileName() + "'" +
            ", deviceId='" + getDeviceId() + "'" +
            ", binaryFile='" + getBinaryFile() + "'" +
            ", binaryFileContentType='" + getBinaryFileContentType() + "'" +
            ", dateTime='" + getDateTime() + "'" +
            ", customerId='" + getCustomerId() + "'" +
            ", groupID='" + getGroupID() + "'" +
            "}";
    }
}
