/**
 * Domain objects.
 */
package com.montage.connect.domain;
