/**
 * Logging aspect.
 */
package com.montage.connect.aop.logging;
