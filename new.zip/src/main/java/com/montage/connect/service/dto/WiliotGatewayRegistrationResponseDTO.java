package com.montage.connect.service.dto;


/**
 * A DTO representing a Gateway registration response, with only the public attributes.
 */
public class WiliotGatewayRegistrationResponseDTO {
    private String accessToken;
    private String expiresIn;
    private String wiliotGatewayID;
    private String williotOwnerID;
    private String wiliotMQTTUrl;


    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(String expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getWiliotGatewayID() {
        return wiliotGatewayID;
    }

    public void setWiliotGatewayID(String wiliotGatewayID) {
        this.wiliotGatewayID = wiliotGatewayID;
    }

    public String getWilliotOwnerID() {
        return williotOwnerID;
    }

    public void setWilliotOwnerID(String williotOwnerID) {
        this.williotOwnerID = williotOwnerID;
    }

    public String getWiliotMQTTUrl() {
        return wiliotMQTTUrl;
    }

    public void setWiliotMQTTUrl(String wiliotMQTTUrl) {
        this.wiliotMQTTUrl = wiliotMQTTUrl;
    }

    @Override
    public String toString() {
        return "WiliotGatewayRegistrationResponseDTO{" +
            "accessToken='" + accessToken + '\'' +
            ", expiresIn='" + expiresIn + '\'' +
            ", wiliotGatewayID='" + wiliotGatewayID + '\'' +
            ", williotOwnerID='" + williotOwnerID + '\'' +
            ", wiliotMQTTUrl='" + wiliotMQTTUrl + '\'' +
            '}';
    }
}
