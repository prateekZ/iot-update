package com.montage.connect.service.comparators;

import com.montage.connect.domain.DeviceConfigUpdate;
import java.util.Comparator;

public class CustomDeviceConfigUpdateDateComparator implements Comparator<DeviceConfigUpdate> {

    @Override
    public int compare(DeviceConfigUpdate o1, DeviceConfigUpdate o2) {
        return o1.getDateTime().compareTo(o2.getDateTime());
    }
}
