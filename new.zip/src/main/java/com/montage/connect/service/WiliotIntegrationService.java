package com.montage.connect.service;

import com.montage.connect.service.dto.GatewayRegistrationRequest;
import com.montage.connect.service.dto.WiliotGatewayRegistrationRequestDTO;
import com.montage.connect.service.dto.WiliotGatewayRegistrationResponseDTO;
import com.montage.connect.web.rest.errors.BadRequestAlertException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

@Service
public class WiliotIntegrationService {

    private final Logger log = LoggerFactory.getLogger(WiliotIntegrationService.class);

    private final RestTemplate restTemplate;

    @Value("${wiliot.cloud.v1.auth.token.api.gcp.url}")
    private String wiliotGcpAuthTokenUrl;

    @Value("${wiliot.cloud.v1.gateway.registration.api.gcp.url}")
    private String wiliotGcpGatewayRegistrationApiUrl;

    @Value("${wiliot.edge.security.key}")
    private String wiliotEdgeSecurityKey;

    @Value("${wiliot.gcp-mqtt-url}")
    private String wiliotGcpMqttUrl;

    @Value("${wiliot.gateway.type}")
    private String wiliotGatewayType;

    @Value("${wiliot.owner.account.id}")
    private String wiliotOwnerAccountId;
    //
    @Value("${wiliot.region}")
    private String wiliotRegion;


    WiliotIntegrationService (RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public JSONObject getAuthTokenFromWiliotGateway() throws ParseException {
        // First API for wiliot auth token
        JSONParser jsonParser = new JSONParser();
        String responseBodyOfAuthTokenApi = "";

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.put("Authorization", Arrays.asList(wiliotEdgeSecurityKey));
        HttpEntity<String> requestBody = new HttpEntity<>(headers);

        try {
            responseBodyOfAuthTokenApi = restTemplate.exchange(wiliotGcpAuthTokenUrl, HttpMethod.POST, requestBody, String.class).getBody();
        } catch (Exception exception) {
            throw new BadRequestAlertException(exception.getMessage(), exception.getLocalizedMessage(), "WiliotException");
        }

        JSONObject jsonObject = (JSONObject) jsonParser.parse(responseBodyOfAuthTokenApi);
//        String accessToken = (String) jsonObject.get("access_token");
        return jsonObject;
    }

    public WiliotGatewayRegistrationResponseDTO initWiliotGatewayRegistration(WiliotGatewayRegistrationRequestDTO gatewayId) throws ParseException, BadRequestAlertException {

        // First API for wiliot auth token
        JSONParser jsonParser = new JSONParser();
        String responseBodyOfAuthTokenApi = "";
        String responseBodyOfGatewayRegistrationApi = "";

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.put("Authorization", Arrays.asList(wiliotEdgeSecurityKey));
        HttpEntity<String> requestBody = new HttpEntity<>(headers);

        try {
            responseBodyOfAuthTokenApi = restTemplate.exchange(wiliotGcpAuthTokenUrl, HttpMethod.POST, requestBody, String.class).getBody();
        } catch (Exception exception) {
            throw new BadRequestAlertException(exception.getMessage(), exception.getLocalizedMessage(), "WiliotException");
        }

        JSONObject jsonObject = (JSONObject) jsonParser.parse(responseBodyOfAuthTokenApi);
        String accessToken = (String) jsonObject.get("access_token");

        // Second API for wiliot gateway registration
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.put("Authorization", Arrays.asList(accessToken));
        GatewayRegistrationRequest gatewayRequest = new GatewayRegistrationRequest();
        gatewayRequest.setGatewayType(wiliotGatewayType);
        gatewayRequest.setGatewayName(gatewayId.getGatewayId());
        HttpEntity<GatewayRegistrationRequest> gatewayRegistrationRequestBody = new HttpEntity<>(gatewayRequest, headers);

        try {
            responseBodyOfGatewayRegistrationApi = restTemplate.exchange(wiliotGcpGatewayRegistrationApiUrl + gatewayId.getGatewayId()+"/"+wiliotGatewayType, HttpMethod.POST, gatewayRegistrationRequestBody, String.class).getBody();
        } catch (Exception exception) {
            throw new BadRequestAlertException(exception.getMessage(), exception.getLocalizedMessage(), "WiliotException");
        }

        WiliotGatewayRegistrationResponseDTO responseDTO  = new WiliotGatewayRegistrationResponseDTO();
        if(responseBodyOfGatewayRegistrationApi != null && (!responseBodyOfGatewayRegistrationApi.isEmpty())) {
            JSONObject responseJson = (JSONObject) jsonParser.parse(responseBodyOfGatewayRegistrationApi);
            JSONObject dataObject = (JSONObject) responseJson.get("data");
            responseDTO.setAccessToken( (dataObject.get("access_token") == null) ? null : dataObject.get("access_token").toString());
            responseDTO.setExpiresIn( (dataObject.get("expires_in") == null) ? null : dataObject.get("expires_in").toString());
            responseDTO.setWilliotOwnerID( (dataObject.get("ownerId") == null) ? null : dataObject.get("ownerId").toString());
            responseDTO.setWiliotGatewayID(gatewayId.getGatewayId());
            responseDTO.setWiliotMQTTUrl(wiliotGcpMqttUrl);
        }

        return responseDTO;
    }

}
