package com.montage.connect.service.dto;

public class GatewayRegistrationRequest {

    private String gatewayType;
    private String gatewayName;
    public String getGatewayType() {
        return gatewayType;
    }
    public void setGatewayType(String gatewayType) {
        this.gatewayType = gatewayType;
    }
    public String getGatewayName() {
        return gatewayName;
    }
    public void setGatewayName(String gatewayName) {
        this.gatewayName = gatewayName;
    }


    
}
