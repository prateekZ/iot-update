package com.montage.connect.service;

import com.montage.connect.domain.DeviceConfigUpdate;
import com.montage.connect.service.dto.DeviceConfigUpdateDTO;
import com.montage.connect.web.rest.errors.BadRequestAlertException;
import java.util.Optional;
import org.json.simple.parser.ParseException;

/**
 * Service Interface for managing {@link com.montage.connect.domain.DeviceConfigUpdate}.
 */
public interface DeviceConfigUpdateService {
    /**
     * Save a deviceConfigUpdate.
     *
     * @param deviceConfigUpdateDTO the entity to save.
     * @return the persisted entity.
     */
    DeviceConfigUpdateDTO save(DeviceConfigUpdateDTO deviceConfigUpdateDTO);

    /**
     * Updates a deviceConfigUpdate.
     *
     * @param deviceConfigUpdateDTO the entity to update.
     * @return the persisted entity.
     */
    DeviceConfigUpdateDTO update(DeviceConfigUpdateDTO deviceConfigUpdateDTO);

    /**
     * Partially updates a deviceConfigUpdate.
     *
     * @param deviceConfigUpdateDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<DeviceConfigUpdateDTO> partialUpdate(DeviceConfigUpdateDTO deviceConfigUpdateDTO);

    /**
     * Get the "id" deviceConfigUpdate.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<DeviceConfigUpdateDTO> findOne(Long id);

    /**
     * Delete the "id" deviceConfigUpdate.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);

    /**
     * Get the device config file from the json
     * @param deviceConfig
     * @return
     */
    DeviceConfigUpdate getDeviceConfigFile(String deviceConfig) throws ParseException, BadRequestAlertException;
}
