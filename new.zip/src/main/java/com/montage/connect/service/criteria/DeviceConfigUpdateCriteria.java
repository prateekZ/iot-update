package com.montage.connect.service.criteria;

import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;
import org.springdoc.core.annotations.ParameterObject;
import tech.jhipster.service.Criteria;
import tech.jhipster.service.filter.*;

/**
 * Criteria class for the {@link com.montage.connect.domain.DeviceConfigUpdate} entity. This class is used
 * in {@link com.montage.connect.web.rest.DeviceConfigUpdateResource} to receive all the possible filtering options from
 * the Http GET request parameters.
 * For example the following could be a valid request:
 * {@code /device-config-updates?id.greaterThan=5&attr1.contains=something&attr2.specified=false}
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
@ParameterObject
@SuppressWarnings("common-java:DuplicatedBlocks")
public class DeviceConfigUpdateCriteria implements Serializable, Criteria {

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private StringFilter configVersion;

    private StringFilter firmwareVersion;

    private StringFilter fileName;

    private StringFilter deviceId;

    private InstantFilter dateTime;

    private StringFilter customerId;

    private StringFilter groupID;

    private Boolean distinct;

    public DeviceConfigUpdateCriteria() {}

    public DeviceConfigUpdateCriteria(DeviceConfigUpdateCriteria other) {
        this.id = other.optionalId().map(LongFilter::copy).orElse(null);
        this.configVersion = other.optionalConfigVersion().map(StringFilter::copy).orElse(null);
        this.firmwareVersion = other.optionalFirmwareVersion().map(StringFilter::copy).orElse(null);
        this.fileName = other.optionalFileName().map(StringFilter::copy).orElse(null);
        this.deviceId = other.optionalDeviceId().map(StringFilter::copy).orElse(null);
        this.dateTime = other.optionalDateTime().map(InstantFilter::copy).orElse(null);
        this.customerId = other.optionalCustomerId().map(StringFilter::copy).orElse(null);
        this.groupID = other.optionalGroupID().map(StringFilter::copy).orElse(null);
        this.distinct = other.distinct;
    }

    @Override
    public DeviceConfigUpdateCriteria copy() {
        return new DeviceConfigUpdateCriteria(this);
    }

    public LongFilter getId() {
        return id;
    }

    public Optional<LongFilter> optionalId() {
        return Optional.ofNullable(id);
    }

    public LongFilter id() {
        if (id == null) {
            setId(new LongFilter());
        }
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public StringFilter getConfigVersion() {
        return configVersion;
    }

    public Optional<StringFilter> optionalConfigVersion() {
        return Optional.ofNullable(configVersion);
    }

    public StringFilter configVersion() {
        if (configVersion == null) {
            setConfigVersion(new StringFilter());
        }
        return configVersion;
    }

    public void setConfigVersion(StringFilter configVersion) {
        this.configVersion = configVersion;
    }

    public StringFilter getFirmwareVersion() {
        return firmwareVersion;
    }

    public Optional<StringFilter> optionalFirmwareVersion() {
        return Optional.ofNullable(firmwareVersion);
    }

    public StringFilter firmwareVersion() {
        if (firmwareVersion == null) {
            setFirmwareVersion(new StringFilter());
        }
        return firmwareVersion;
    }

    public void setFirmwareVersion(StringFilter firmwareVersion) {
        this.firmwareVersion = firmwareVersion;
    }

    public StringFilter getFileName() {
        return fileName;
    }

    public Optional<StringFilter> optionalFileName() {
        return Optional.ofNullable(fileName);
    }

    public StringFilter fileName() {
        if (fileName == null) {
            setFileName(new StringFilter());
        }
        return fileName;
    }

    public void setFileName(StringFilter fileName) {
        this.fileName = fileName;
    }

    public StringFilter getDeviceId() {
        return deviceId;
    }

    public Optional<StringFilter> optionalDeviceId() {
        return Optional.ofNullable(deviceId);
    }

    public StringFilter deviceId() {
        if (deviceId == null) {
            setDeviceId(new StringFilter());
        }
        return deviceId;
    }

    public void setDeviceId(StringFilter deviceId) {
        this.deviceId = deviceId;
    }

    public InstantFilter getDateTime() {
        return dateTime;
    }

    public Optional<InstantFilter> optionalDateTime() {
        return Optional.ofNullable(dateTime);
    }

    public InstantFilter dateTime() {
        if (dateTime == null) {
            setDateTime(new InstantFilter());
        }
        return dateTime;
    }

    public void setDateTime(InstantFilter dateTime) {
        this.dateTime = dateTime;
    }

    public StringFilter getCustomerId() {
        return customerId;
    }

    public Optional<StringFilter> optionalCustomerId() {
        return Optional.ofNullable(customerId);
    }

    public StringFilter customerId() {
        if (customerId == null) {
            setCustomerId(new StringFilter());
        }
        return customerId;
    }

    public void setCustomerId(StringFilter customerId) {
        this.customerId = customerId;
    }

    public StringFilter getGroupID() {
        return groupID;
    }

    public Optional<StringFilter> optionalGroupID() {
        return Optional.ofNullable(groupID);
    }

    public StringFilter groupID() {
        if (groupID == null) {
            setGroupID(new StringFilter());
        }
        return groupID;
    }

    public void setGroupID(StringFilter groupID) {
        this.groupID = groupID;
    }

    public Boolean getDistinct() {
        return distinct;
    }

    public Optional<Boolean> optionalDistinct() {
        return Optional.ofNullable(distinct);
    }

    public Boolean distinct() {
        if (distinct == null) {
            setDistinct(true);
        }
        return distinct;
    }

    public void setDistinct(Boolean distinct) {
        this.distinct = distinct;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final DeviceConfigUpdateCriteria that = (DeviceConfigUpdateCriteria) o;
        return (
            Objects.equals(id, that.id) &&
            Objects.equals(configVersion, that.configVersion) &&
            Objects.equals(firmwareVersion, that.firmwareVersion) &&
            Objects.equals(fileName, that.fileName) &&
            Objects.equals(deviceId, that.deviceId) &&
            Objects.equals(dateTime, that.dateTime) &&
            Objects.equals(customerId, that.customerId) &&
            Objects.equals(groupID, that.groupID) &&
            Objects.equals(distinct, that.distinct)
        );
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, configVersion, firmwareVersion, fileName, deviceId, dateTime, customerId, groupID, distinct);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "DeviceConfigUpdateCriteria{" +
            optionalId().map(f -> "id=" + f + ", ").orElse("") +
            optionalConfigVersion().map(f -> "configVersion=" + f + ", ").orElse("") +
            optionalFirmwareVersion().map(f -> "firmwareVersion=" + f + ", ").orElse("") +
            optionalFileName().map(f -> "fileName=" + f + ", ").orElse("") +
            optionalDeviceId().map(f -> "deviceId=" + f + ", ").orElse("") +
            optionalDateTime().map(f -> "dateTime=" + f + ", ").orElse("") +
            optionalCustomerId().map(f -> "customerId=" + f + ", ").orElse("") +
            optionalGroupID().map(f -> "groupID=" + f + ", ").orElse("") +
            optionalDistinct().map(f -> "distinct=" + f + ", ").orElse("") +
        "}";
    }
}
