/**
 * Data transfer objects for rest mapping.
 */
package com.montage.connect.service.dto;
