package com.montage.connect.service.dto;

public class WiliotGatewayRegistrationRequestDTO {

    private String gatewayId;
    private String gatewayType;
    private String customerId;
    private String groupId;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getGatewayType() {
        return gatewayType;
    }

    public void setGatewayType(String gatewayType) {
        this.gatewayType = gatewayType;
    }

    public String getGatewayId() {
        return gatewayId;
    }

    public void setGatewayId(String gatewayId) {
        this.gatewayId = gatewayId;
    }

    @Override
    public String toString() {
        return "WiliotGatewayRegistrationRequestDTO{" +
            "gatewayName='" + gatewayId + '\'' +
            ", gatewayType='" + gatewayType + '\'' +
            ", customerId='" + customerId + '\'' +
            ", groupId='" + groupId + '\'' +
            '}';
    }

}
