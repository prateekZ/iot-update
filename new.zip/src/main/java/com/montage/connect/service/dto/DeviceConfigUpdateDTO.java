package com.montage.connect.service.dto;

import jakarta.persistence.Lob;
import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

/**
 * A DTO for the {@link com.montage.connect.domain.DeviceConfigUpdate} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class DeviceConfigUpdateDTO implements Serializable {

    private Long id;

    private String configVersion;

    private String firmwareVersion;

    private String fileName;

    private String deviceId;

    @Lob
    private byte[] binaryFile;

    private String binaryFileContentType;

    private Instant dateTime;

    private String customerId;

    private String groupID;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getConfigVersion() {
        return configVersion;
    }

    public void setConfigVersion(String configVersion) {
        this.configVersion = configVersion;
    }

    public String getFirmwareVersion() {
        return firmwareVersion;
    }

    public void setFirmwareVersion(String firmwareVersion) {
        this.firmwareVersion = firmwareVersion;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public byte[] getBinaryFile() {
        return binaryFile;
    }

    public void setBinaryFile(byte[] binaryFile) {
        this.binaryFile = binaryFile;
    }

    public String getBinaryFileContentType() {
        return binaryFileContentType;
    }

    public void setBinaryFileContentType(String binaryFileContentType) {
        this.binaryFileContentType = binaryFileContentType;
    }

    public Instant getDateTime() {
        return dateTime;
    }

    public void setDateTime(Instant dateTime) {
        this.dateTime = dateTime;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getGroupID() {
        return groupID;
    }

    public void setGroupID(String groupID) {
        this.groupID = groupID;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof DeviceConfigUpdateDTO)) {
            return false;
        }

        DeviceConfigUpdateDTO deviceConfigUpdateDTO = (DeviceConfigUpdateDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, deviceConfigUpdateDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "DeviceConfigUpdateDTO{" +
            "id=" + getId() +
            ", configVersion='" + getConfigVersion() + "'" +
            ", firmwareVersion='" + getFirmwareVersion() + "'" +
            ", fileName='" + getFileName() + "'" +
            ", deviceId='" + getDeviceId() + "'" +
            ", binaryFile='" + getBinaryFile() + "'" +
            ", dateTime='" + getDateTime() + "'" +
            ", customerId='" + getCustomerId() + "'" +
            ", groupID='" + getGroupID() + "'" +
            "}";
    }
}
