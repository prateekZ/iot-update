package com.montage.connect.service.impl;

import com.montage.connect.domain.DeviceConfigUpdate;
import com.montage.connect.repository.DeviceConfigUpdateRepository;
import com.montage.connect.service.DeviceConfigUpdateService;
import com.montage.connect.service.comparators.CustomDeviceConfigUpdateDateComparator;
import com.montage.connect.service.dto.DeviceConfigUpdateDTO;
import com.montage.connect.service.mapper.DeviceConfigUpdateMapper;
import com.montage.connect.web.rest.errors.BadRequestAlertException;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

import com.montage.connect.web.rest.errors.ErrorConstants;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.montage.connect.domain.DeviceConfigUpdate}.
 */
@Service
@Transactional
public class DeviceConfigUpdateServiceImpl implements DeviceConfigUpdateService {

    private final Logger log = LoggerFactory.getLogger(DeviceConfigUpdateServiceImpl.class);

    private final DeviceConfigUpdateRepository deviceConfigUpdateRepository;

    private final DeviceConfigUpdateMapper deviceConfigUpdateMapper;

    public DeviceConfigUpdateServiceImpl(
        DeviceConfigUpdateRepository deviceConfigUpdateRepository,
        DeviceConfigUpdateMapper deviceConfigUpdateMapper
    ) {
        this.deviceConfigUpdateRepository = deviceConfigUpdateRepository;
        this.deviceConfigUpdateMapper = deviceConfigUpdateMapper;
    }

    @Override
    public DeviceConfigUpdateDTO save(DeviceConfigUpdateDTO deviceConfigUpdateDTO) {
        log.debug("Request to save DeviceConfigUpdate : {}", deviceConfigUpdateDTO);
        deviceConfigUpdateDTO.setDateTime(Instant.now());
        DeviceConfigUpdate deviceConfigUpdate = deviceConfigUpdateMapper.toEntity(deviceConfigUpdateDTO);
        deviceConfigUpdate = deviceConfigUpdateRepository.save(deviceConfigUpdate);
        return deviceConfigUpdateMapper.toDto(deviceConfigUpdate);
    }

    @Override
    public DeviceConfigUpdateDTO update(DeviceConfigUpdateDTO deviceConfigUpdateDTO) {
        log.debug("Request to update DeviceConfigUpdate : {}", deviceConfigUpdateDTO);
        DeviceConfigUpdate deviceConfigUpdate = deviceConfigUpdateMapper.toEntity(deviceConfigUpdateDTO);
        deviceConfigUpdate = deviceConfigUpdateRepository.save(deviceConfigUpdate);
        return deviceConfigUpdateMapper.toDto(deviceConfigUpdate);
    }

    @Override
    public Optional<DeviceConfigUpdateDTO> partialUpdate(DeviceConfigUpdateDTO deviceConfigUpdateDTO) {
        log.debug("Request to partially update DeviceConfigUpdate : {}", deviceConfigUpdateDTO);

        return deviceConfigUpdateRepository
            .findById(deviceConfigUpdateDTO.getId())
            .map(existingDeviceConfigUpdate -> {
                deviceConfigUpdateMapper.partialUpdate(existingDeviceConfigUpdate, deviceConfigUpdateDTO);

                return existingDeviceConfigUpdate;
            })
            .map(deviceConfigUpdateRepository::save)
            .map(deviceConfigUpdateMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<DeviceConfigUpdateDTO> findOne(Long id) {
        log.debug("Request to get DeviceConfigUpdate : {}", id);
        return deviceConfigUpdateRepository.findById(id).map(deviceConfigUpdateMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete DeviceConfigUpdate : {}", id);
        deviceConfigUpdateRepository.deleteById(id);
    }

    @Override
    public DeviceConfigUpdate getDeviceConfigFile(String deviceConfig) throws ParseException, BadRequestAlertException {
        JSONParser jsonParser = new JSONParser();
        JSONObject jsonObject = (JSONObject) jsonParser.parse(deviceConfig);
        if(jsonObject.get("deviceId") == null) {
            throw new BadRequestAlertException("Device_Id cannot be null.", "DeviceConfigUpdate", "deviceIdNull");
        }
        if (jsonObject.get("firmwareVersion") != null && (!jsonObject.get("firmwareVersion").toString().isEmpty())) {
            return getDeviceConfigFileBytesForFirmwareVersion((String) jsonObject.get("deviceId"), (String) jsonObject.get("firmwareVersion"));
        } else if (jsonObject.get("configVersion") != null && (!jsonObject.get("configVersion").toString().isEmpty())) {
            return getDeviceConfigFileBytesForConfigVersion((String) jsonObject.get("deviceId"), (String) jsonObject.get("configVersion"));
        }
        return null;
    }

    private DeviceConfigUpdate getDeviceConfigFileBytesForFirmwareVersion(String deviceId, String firmwareVersion) {
        log.debug("Request to getDeviceConfigFileBytesForFirmwareVersion : {} , device_ID : {}", firmwareVersion, deviceId);
        List<DeviceConfigUpdate> listOfDeviceConfigUpdateByFirmwareVersion = deviceConfigUpdateRepository.findByDeviceIdAndFirmwareVersion(deviceId, firmwareVersion);
        if (listOfDeviceConfigUpdateByFirmwareVersion.isEmpty()) {
            throw new BadRequestAlertException(ErrorConstants.DEVICE_CONFIG_NOT_FOUND, "DeviceConfig not found for this device_Id", "DeviceConfigUpdate", "Invalid device_id or firmware_version");
        }
        listOfDeviceConfigUpdateByFirmwareVersion.sort(new CustomDeviceConfigUpdateDateComparator());
        return listOfDeviceConfigUpdateByFirmwareVersion.get(
            listOfDeviceConfigUpdateByFirmwareVersion.size() - 1
        );
    }

    private DeviceConfigUpdate getDeviceConfigFileBytesForConfigVersion(String deviceId, String configVersion) {
        log.debug("Request to getDeviceConfigFileBytesForConfigVersion : {} , device_ID : {}", configVersion, deviceId);
        List<DeviceConfigUpdate> listOfDeviceConfigUpdateByConfigVersion = deviceConfigUpdateRepository.findByDeviceIdAndConfigVersion(deviceId, configVersion);
        if (listOfDeviceConfigUpdateByConfigVersion.isEmpty()) {
            throw new BadRequestAlertException(ErrorConstants.DEVICE_CONFIG_NOT_FOUND, "DeviceConfig not found for this device_Id", "DeviceConfigUpdate", "Invalid device_id or config_version");
        }
        listOfDeviceConfigUpdateByConfigVersion.sort(new CustomDeviceConfigUpdateDateComparator());
        return listOfDeviceConfigUpdateByConfigVersion.get(
            listOfDeviceConfigUpdateByConfigVersion.size() - 1
        );
    }
}
