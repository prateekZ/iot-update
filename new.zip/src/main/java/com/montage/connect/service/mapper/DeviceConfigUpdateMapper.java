package com.montage.connect.service.mapper;

import com.montage.connect.domain.DeviceConfigUpdate;
import com.montage.connect.service.dto.DeviceConfigUpdateDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link DeviceConfigUpdate} and its DTO {@link DeviceConfigUpdateDTO}.
 */
@Mapper(componentModel = "spring")
public interface DeviceConfigUpdateMapper extends EntityMapper<DeviceConfigUpdateDTO, DeviceConfigUpdate> {}
