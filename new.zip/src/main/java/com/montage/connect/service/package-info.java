/**
 * Service layer.
 */
package com.montage.connect.service;
