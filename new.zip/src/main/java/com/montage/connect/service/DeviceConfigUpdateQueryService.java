package com.montage.connect.service;

import com.montage.connect.domain.*; // for static metamodels
import com.montage.connect.domain.DeviceConfigUpdate;
import com.montage.connect.repository.DeviceConfigUpdateRepository;
import com.montage.connect.service.criteria.DeviceConfigUpdateCriteria;
import com.montage.connect.service.dto.DeviceConfigUpdateDTO;
import com.montage.connect.service.mapper.DeviceConfigUpdateMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tech.jhipster.service.QueryService;

/**
 * Service for executing complex queries for {@link DeviceConfigUpdate} entities in the database.
 * The main input is a {@link DeviceConfigUpdateCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link Page} of {@link DeviceConfigUpdateDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class DeviceConfigUpdateQueryService extends QueryService<DeviceConfigUpdate> {

    private static final Logger log = LoggerFactory.getLogger(DeviceConfigUpdateQueryService.class);

    private final DeviceConfigUpdateRepository deviceConfigUpdateRepository;

    private final DeviceConfigUpdateMapper deviceConfigUpdateMapper;

    public DeviceConfigUpdateQueryService(
        DeviceConfigUpdateRepository deviceConfigUpdateRepository,
        DeviceConfigUpdateMapper deviceConfigUpdateMapper
    ) {
        this.deviceConfigUpdateRepository = deviceConfigUpdateRepository;
        this.deviceConfigUpdateMapper = deviceConfigUpdateMapper;
    }

    /**
     * Return a {@link Page} of {@link DeviceConfigUpdateDTO} which matches the criteria from the database.
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<DeviceConfigUpdateDTO> findByCriteria(DeviceConfigUpdateCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<DeviceConfigUpdate> specification = createSpecification(criteria);
        return deviceConfigUpdateRepository.findAll(specification, page).map(deviceConfigUpdateMapper::toDto);
    }

    /**
     * Return the number of matching entities in the database.
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(DeviceConfigUpdateCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<DeviceConfigUpdate> specification = createSpecification(criteria);
        return deviceConfigUpdateRepository.count(specification);
    }

    /**
     * Function to convert {@link DeviceConfigUpdateCriteria} to a {@link Specification}
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching {@link Specification} of the entity.
     */
    protected Specification<DeviceConfigUpdate> createSpecification(DeviceConfigUpdateCriteria criteria) {
        Specification<DeviceConfigUpdate> specification = Specification.where(null);
        if (criteria != null) {
            // This has to be called first, because the distinct method returns null
            if (criteria.getDistinct() != null) {
                specification = specification.and(distinct(criteria.getDistinct()));
            }
            if (criteria.getId() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getId(), DeviceConfigUpdate_.id));
            }
            if (criteria.getConfigVersion() != null) {
                specification = specification.and(buildStringSpecification(criteria.getConfigVersion(), DeviceConfigUpdate_.configVersion));
            }
            if (criteria.getFirmwareVersion() != null) {
                specification = specification.and(
                    buildStringSpecification(criteria.getFirmwareVersion(), DeviceConfigUpdate_.firmwareVersion)
                );
            }
            if (criteria.getFileName() != null) {
                specification = specification.and(buildStringSpecification(criteria.getFileName(), DeviceConfigUpdate_.fileName));
            }
            if (criteria.getDeviceId() != null) {
                specification = specification.and(buildStringSpecification(criteria.getDeviceId(), DeviceConfigUpdate_.deviceId));
            }
            if (criteria.getDateTime() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getDateTime(), DeviceConfigUpdate_.dateTime));
            }
            if (criteria.getCustomerId() != null) {
                specification = specification.and(buildStringSpecification(criteria.getCustomerId(), DeviceConfigUpdate_.customerId));
            }
            if (criteria.getGroupID() != null) {
                specification = specification.and(buildStringSpecification(criteria.getGroupID(), DeviceConfigUpdate_.groupID));
            }
        }
        return specification;
    }
}
