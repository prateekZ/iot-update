/**
 * Application configuration.
 */
package com.montage.connect.config;
