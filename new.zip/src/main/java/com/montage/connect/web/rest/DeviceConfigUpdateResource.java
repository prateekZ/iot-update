package com.montage.connect.web.rest;

import com.montage.connect.domain.DeviceConfigUpdate;
import com.montage.connect.repository.DeviceConfigUpdateRepository;
import com.montage.connect.service.DeviceConfigUpdateQueryService;
import com.montage.connect.service.DeviceConfigUpdateService;
import com.montage.connect.service.criteria.DeviceConfigUpdateCriteria;
import com.montage.connect.service.dto.DeviceConfigUpdateDTO;
import com.montage.connect.web.rest.errors.BadRequestAlertException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.aspectj.lang.annotation.RequiredTypes;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.montage.connect.domain.DeviceConfigUpdate}.
 */
@RestController
@RequestMapping("/api/device-config-updates")
public class DeviceConfigUpdateResource {

    private final Logger log = LoggerFactory.getLogger(DeviceConfigUpdateResource.class);

    private static final String ENTITY_NAME = "deviceConfigUpdate";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final DeviceConfigUpdateService deviceConfigUpdateService;

    private final DeviceConfigUpdateRepository deviceConfigUpdateRepository;

    private final DeviceConfigUpdateQueryService deviceConfigUpdateQueryService;

    public DeviceConfigUpdateResource(
        DeviceConfigUpdateService deviceConfigUpdateService,
        DeviceConfigUpdateRepository deviceConfigUpdateRepository,
        DeviceConfigUpdateQueryService deviceConfigUpdateQueryService
    ) {
        this.deviceConfigUpdateService = deviceConfigUpdateService;
        this.deviceConfigUpdateRepository = deviceConfigUpdateRepository;
        this.deviceConfigUpdateQueryService = deviceConfigUpdateQueryService;
    }

    /**
     * {@code POST  /device-config-updates} : Create a new deviceConfigUpdate.
     *
     * @param deviceConfigUpdateDTO the deviceConfigUpdateDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new deviceConfigUpdateDTO, or with status {@code 400 (Bad Request)} if the deviceConfigUpdate has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<DeviceConfigUpdateDTO> createDeviceConfigUpdate(@RequestBody DeviceConfigUpdateDTO deviceConfigUpdateDTO)
        throws URISyntaxException {
        log.debug("REST request to save DeviceConfigUpdate : {}", deviceConfigUpdateDTO);
        if (deviceConfigUpdateDTO.getId() != null) {
            throw new BadRequestAlertException("A new deviceConfigUpdate cannot already have an ID", ENTITY_NAME, "idexists");
        }
        deviceConfigUpdateDTO = deviceConfigUpdateService.save(deviceConfigUpdateDTO);
        return ResponseEntity.created(new URI("/api/device-config-updates/" + deviceConfigUpdateDTO.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, deviceConfigUpdateDTO.getId().toString()))
            .body(deviceConfigUpdateDTO);
    }

    /**
     * {@code PUT  /device-config-updates/:id} : Updates an existing deviceConfigUpdate.
     *
     * @param id the id of the deviceConfigUpdateDTO to save.
     * @param deviceConfigUpdateDTO the deviceConfigUpdateDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated deviceConfigUpdateDTO,
     * or with status {@code 400 (Bad Request)} if the deviceConfigUpdateDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the deviceConfigUpdateDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<DeviceConfigUpdateDTO> updateDeviceConfigUpdate(
        @PathVariable(value = "id", required = false) final Long id,
        @RequestBody DeviceConfigUpdateDTO deviceConfigUpdateDTO
    ) throws URISyntaxException {
        log.debug("REST request to update DeviceConfigUpdate : {}, {}", id, deviceConfigUpdateDTO);
        if (deviceConfigUpdateDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, deviceConfigUpdateDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!deviceConfigUpdateRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        deviceConfigUpdateDTO = deviceConfigUpdateService.update(deviceConfigUpdateDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, deviceConfigUpdateDTO.getId().toString()))
            .body(deviceConfigUpdateDTO);
    }

    /**
     * {@code PATCH  /device-config-updates/:id} : Partial updates given fields of an existing deviceConfigUpdate, field will ignore if it is null
     *
     * @param id the id of the deviceConfigUpdateDTO to save.
     * @param deviceConfigUpdateDTO the deviceConfigUpdateDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated deviceConfigUpdateDTO,
     * or with status {@code 400 (Bad Request)} if the deviceConfigUpdateDTO is not valid,
     * or with status {@code 404 (Not Found)} if the deviceConfigUpdateDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the deviceConfigUpdateDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<DeviceConfigUpdateDTO> partialUpdateDeviceConfigUpdate(
        @PathVariable(value = "id", required = false) final Long id,
        @RequestBody DeviceConfigUpdateDTO deviceConfigUpdateDTO
    ) throws URISyntaxException {
        log.debug("REST request to partial update DeviceConfigUpdate partially : {}, {}", id, deviceConfigUpdateDTO);
        if (deviceConfigUpdateDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, deviceConfigUpdateDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!deviceConfigUpdateRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<DeviceConfigUpdateDTO> result = deviceConfigUpdateService.partialUpdate(deviceConfigUpdateDTO);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, deviceConfigUpdateDTO.getId().toString())
        );
    }

    /**
     * {@code GET  /device-config-updates} : get all the deviceConfigUpdates.
     *
     * @param pageable the pagination information.
     * @param criteria the criteria which the requested entities should match.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of deviceConfigUpdates in body.
     */
    @GetMapping("")
    public ResponseEntity<List<DeviceConfigUpdateDTO>> getAllDeviceConfigUpdates(
        DeviceConfigUpdateCriteria criteria,
        @org.springdoc.core.annotations.ParameterObject Pageable pageable
    ) {
        log.debug("REST request to get DeviceConfigUpdates by criteria: {}", criteria);

        Page<DeviceConfigUpdateDTO> page = deviceConfigUpdateQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /device-config-updates/count} : count all the deviceConfigUpdates.
     *
     * @param criteria the criteria which the requested entities should match.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the count in body.
     */
    @GetMapping("/count")
    public ResponseEntity<Long> countDeviceConfigUpdates(DeviceConfigUpdateCriteria criteria) {
        log.debug("REST request to count DeviceConfigUpdates by criteria: {}", criteria);
        return ResponseEntity.ok().body(deviceConfigUpdateQueryService.countByCriteria(criteria));
    }

    /**
     * {@code GET  /device-config-updates/:id} : get the "id" deviceConfigUpdate.
     *
     * @param id the id of the deviceConfigUpdateDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the deviceConfigUpdateDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<DeviceConfigUpdateDTO> getDeviceConfigUpdate(@PathVariable("id") Long id) {
        log.debug("REST request to get DeviceConfigUpdate : {}", id);
        Optional<DeviceConfigUpdateDTO> deviceConfigUpdateDTO = deviceConfigUpdateService.findOne(id);
        return ResponseUtil.wrapOrNotFound(deviceConfigUpdateDTO);
    }

    /**
     * {@code DELETE  /device-config-updates/:id} : delete the "id" deviceConfigUpdate.
     *
     * @param id the id of the deviceConfigUpdateDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDeviceConfigUpdate(@PathVariable("id") Long id) {
        log.debug("REST request to delete DeviceConfigUpdate : {}", id);
        deviceConfigUpdateService.delete(id);
        return ResponseEntity.noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }

    /**
     * {@code POST  /device-config-updates/create} : Create a new deviceConfigUpdate with file.
     *
     * @param deviceConfigUpdateDTO the deviceConfigUpdateDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new deviceConfigUpdateDTO, or with status {@code 400 (Bad Request)} if the deviceConfigUpdate has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/create")
    public ResponseEntity<DeviceConfigUpdateDTO> createDeviceConfigUpdateWithMultipartFile(
        @RequestPart("deviceConfigUpdateDTO") DeviceConfigUpdateDTO deviceConfigUpdateDTO,
        @RequestPart("file") MultipartFile file
    ) throws URISyntaxException {
        log.debug("REST request to save DeviceConfigUpdate : {}", deviceConfigUpdateDTO);

        if (deviceConfigUpdateDTO.getId() != null) {
            throw new BadRequestAlertException("A new deviceConfigUpdate cannot already have an ID", ENTITY_NAME, "idexists");
        }
        if (file == null) {
            throw new BadRequestAlertException("File cannot be null", ENTITY_NAME, "filenull");
        }

        if(deviceConfigUpdateDTO.getDeviceId() == null) {
            throw new BadRequestAlertException("A new device_Id cannot be null.", ENTITY_NAME, "deviceIdNull");
        }

        try {
            deviceConfigUpdateDTO.setBinaryFile(file.getBytes());
        } catch (IOException e) {
            throw new BadRequestAlertException(e.getMessage(), ENTITY_NAME, "ioexception");
        }

        deviceConfigUpdateDTO = deviceConfigUpdateService.save(deviceConfigUpdateDTO);
        return ResponseEntity.created(new URI("/api/device-config-updates/" + deviceConfigUpdateDTO.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, deviceConfigUpdateDTO.getId().toString()))
            .body(deviceConfigUpdateDTO);
    }

    /**
     * {@code GET  /device-config-updates/get-file} :
     *
     * @param deviceConfig the criteria which the requested entities should match.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the count in body.
     */
    @PostMapping("/get-file")
    public ResponseEntity<Resource> getDeviceConfigFile(@RequestBody String deviceConfig) throws ParseException, BadRequestAlertException {
        log.debug("REST request to get device config file: {}", deviceConfig);
        if (deviceConfig == null) {
            throw new BadRequestAlertException("DeviceConfig cannot be null or empty.", ENTITY_NAME, "deviceConfigNull");
        }

        DeviceConfigUpdate deviceConfigUpdate = deviceConfigUpdateService.getDeviceConfigFile(deviceConfig);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentDisposition(ContentDisposition.attachment().filename(deviceConfigUpdate.getFileName()).build());
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

        Resource resource = new ByteArrayResource(deviceConfigUpdate.getBinaryFile());
        return new ResponseEntity<>(resource, headers, HttpStatus.OK);
    }
}
