/**
 * Rest layer error handling.
 */
package com.montage.connect.web.rest.errors;
