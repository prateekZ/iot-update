/**
 * Rest layer visual models.
 */
package com.montage.connect.web.rest.vm;
