/**
 * Rest layer.
 */
package com.montage.connect.web.rest;
