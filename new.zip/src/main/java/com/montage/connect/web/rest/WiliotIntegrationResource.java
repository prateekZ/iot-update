package com.montage.connect.web.rest;

import com.montage.connect.service.WiliotIntegrationService;
import com.montage.connect.service.dto.WiliotGatewayRegistrationRequestDTO;
import com.montage.connect.service.dto.WiliotGatewayRegistrationResponseDTO;
import com.montage.connect.web.rest.errors.BadRequestAlertException;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for managing {@link com.montage.connect.domain.DeviceConfigUpdate}.
 */
@RestController
@RequestMapping("/api/wiliot")
public class WiliotIntegrationResource {


    private final Logger log = LoggerFactory.getLogger(WiliotIntegrationResource.class);

    private static final String ENTITY_NAME = "WiliotIntegrationResource";

    private final WiliotIntegrationService wiliotIntegrationService;

    public WiliotIntegrationResource(WiliotIntegrationService wiliotIntegrationService) {
        this.wiliotIntegrationService = wiliotIntegrationService;
    }

    /**
     * {@code POST  api/wiliot/gateway/registration/auth/token} : Create a new Gateway on wiliot..
     */
    @GetMapping("/access-token")
    public ResponseEntity<JSONObject> getAuthTokenFromWiliotGateway() throws ParseException, BadRequestAlertException {
        log.debug("REST request to get wiliot auth token:");
        return ResponseEntity.ok().body(wiliotIntegrationService.getAuthTokenFromWiliotGateway());
    }

    /**
     * {@code GET  api/wiliot/gateway/registration} : Create a new Gateway on wiliot.
     */
    @RequestMapping(value = "/gateway/registration", method = RequestMethod.POST, consumes = "application/json")
    public ResponseEntity<WiliotGatewayRegistrationResponseDTO> initWiliotGatewayRegistration(
        @RequestBody WiliotGatewayRegistrationRequestDTO gatewayRequest
    ) throws ParseException, BadRequestAlertException {
        log.debug("REST request to save gateway on wiliot: {}", gatewayRequest);
        return ResponseEntity.ok()
            .body(wiliotIntegrationService.initWiliotGatewayRegistration(gatewayRequest));
    }
}
