/**
 * Application management.
 */
package com.montage.connect.management;
