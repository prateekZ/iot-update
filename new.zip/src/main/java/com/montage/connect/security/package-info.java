/**
 * Application security utilities.
 */
package com.montage.connect.security;
