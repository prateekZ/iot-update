package com.montage.connect.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.montage.connect.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class DeviceConfigUpdateDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(DeviceConfigUpdateDTO.class);
        DeviceConfigUpdateDTO deviceConfigUpdateDTO1 = new DeviceConfigUpdateDTO();
        deviceConfigUpdateDTO1.setId(1L);
        DeviceConfigUpdateDTO deviceConfigUpdateDTO2 = new DeviceConfigUpdateDTO();
        assertThat(deviceConfigUpdateDTO1).isNotEqualTo(deviceConfigUpdateDTO2);
        deviceConfigUpdateDTO2.setId(deviceConfigUpdateDTO1.getId());
        assertThat(deviceConfigUpdateDTO1).isEqualTo(deviceConfigUpdateDTO2);
        deviceConfigUpdateDTO2.setId(2L);
        assertThat(deviceConfigUpdateDTO1).isNotEqualTo(deviceConfigUpdateDTO2);
        deviceConfigUpdateDTO1.setId(null);
        assertThat(deviceConfigUpdateDTO1).isNotEqualTo(deviceConfigUpdateDTO2);
    }
}
