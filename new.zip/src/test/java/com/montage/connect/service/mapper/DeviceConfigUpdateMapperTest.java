package com.montage.connect.service.mapper;

import static com.montage.connect.domain.DeviceConfigUpdateAsserts.*;
import static com.montage.connect.domain.DeviceConfigUpdateTestSamples.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DeviceConfigUpdateMapperTest {

    private DeviceConfigUpdateMapper deviceConfigUpdateMapper;

    @BeforeEach
    void setUp() {
        deviceConfigUpdateMapper = new DeviceConfigUpdateMapperImpl();
    }

    @Test
    void shouldConvertToDtoAndBack() {
        var expected = getDeviceConfigUpdateSample1();
        var actual = deviceConfigUpdateMapper.toEntity(deviceConfigUpdateMapper.toDto(expected));
        assertDeviceConfigUpdateAllPropertiesEquals(expected, actual);
    }
}
