package com.montage.connect.service.criteria;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.function.BiFunction;
import java.util.function.Function;
import org.assertj.core.api.Condition;
import org.junit.jupiter.api.Test;

class DeviceConfigUpdateCriteriaTest {

    @Test
    void newDeviceConfigUpdateCriteriaHasAllFiltersNullTest() {
        var deviceConfigUpdateCriteria = new DeviceConfigUpdateCriteria();
        assertThat(deviceConfigUpdateCriteria).is(criteriaFiltersAre(filter -> filter == null));
    }

    @Test
    void deviceConfigUpdateCriteriaFluentMethodsCreatesFiltersTest() {
        var deviceConfigUpdateCriteria = new DeviceConfigUpdateCriteria();

        setAllFilters(deviceConfigUpdateCriteria);

        assertThat(deviceConfigUpdateCriteria).is(criteriaFiltersAre(filter -> filter != null));
    }

    @Test
    void deviceConfigUpdateCriteriaCopyCreatesNullFilterTest() {
        var deviceConfigUpdateCriteria = new DeviceConfigUpdateCriteria();
        var copy = deviceConfigUpdateCriteria.copy();

        assertThat(deviceConfigUpdateCriteria).satisfies(
            criteria ->
                assertThat(criteria).is(
                    copyFiltersAre(copy, (a, b) -> (a == null || a instanceof Boolean) ? a == b : (a != b && a.equals(b)))
                ),
            criteria -> assertThat(criteria).isEqualTo(copy),
            criteria -> assertThat(criteria).hasSameHashCodeAs(copy)
        );

        assertThat(copy).satisfies(
            criteria -> assertThat(criteria).is(criteriaFiltersAre(filter -> filter == null)),
            criteria -> assertThat(criteria).isEqualTo(deviceConfigUpdateCriteria)
        );
    }

    @Test
    void deviceConfigUpdateCriteriaCopyDuplicatesEveryExistingFilterTest() {
        var deviceConfigUpdateCriteria = new DeviceConfigUpdateCriteria();
        setAllFilters(deviceConfigUpdateCriteria);

        var copy = deviceConfigUpdateCriteria.copy();

        assertThat(deviceConfigUpdateCriteria).satisfies(
            criteria ->
                assertThat(criteria).is(
                    copyFiltersAre(copy, (a, b) -> (a == null || a instanceof Boolean) ? a == b : (a != b && a.equals(b)))
                ),
            criteria -> assertThat(criteria).isEqualTo(copy),
            criteria -> assertThat(criteria).hasSameHashCodeAs(copy)
        );

        assertThat(copy).satisfies(
            criteria -> assertThat(criteria).is(criteriaFiltersAre(filter -> filter != null)),
            criteria -> assertThat(criteria).isEqualTo(deviceConfigUpdateCriteria)
        );
    }

    @Test
    void toStringVerifier() {
        var deviceConfigUpdateCriteria = new DeviceConfigUpdateCriteria();

        assertThat(deviceConfigUpdateCriteria).hasToString("DeviceConfigUpdateCriteria{}");
    }

    private static void setAllFilters(DeviceConfigUpdateCriteria deviceConfigUpdateCriteria) {
        deviceConfigUpdateCriteria.id();
        deviceConfigUpdateCriteria.configVersion();
        deviceConfigUpdateCriteria.firmwareVersion();
        deviceConfigUpdateCriteria.fileName();
        deviceConfigUpdateCriteria.deviceId();
        deviceConfigUpdateCriteria.dateTime();
        deviceConfigUpdateCriteria.customerId();
        deviceConfigUpdateCriteria.groupID();
        deviceConfigUpdateCriteria.distinct();
    }

    private static Condition<DeviceConfigUpdateCriteria> criteriaFiltersAre(Function<Object, Boolean> condition) {
        return new Condition<>(
            criteria ->
                condition.apply(criteria.getId()) &&
                condition.apply(criteria.getConfigVersion()) &&
                condition.apply(criteria.getFirmwareVersion()) &&
                condition.apply(criteria.getFileName()) &&
                condition.apply(criteria.getDeviceId()) &&
                condition.apply(criteria.getDateTime()) &&
                condition.apply(criteria.getCustomerId()) &&
                condition.apply(criteria.getGroupID()) &&
                condition.apply(criteria.getDistinct()),
            "every filter matches"
        );
    }

    private static Condition<DeviceConfigUpdateCriteria> copyFiltersAre(
        DeviceConfigUpdateCriteria copy,
        BiFunction<Object, Object, Boolean> condition
    ) {
        return new Condition<>(
            criteria ->
                condition.apply(criteria.getId(), copy.getId()) &&
                condition.apply(criteria.getConfigVersion(), copy.getConfigVersion()) &&
                condition.apply(criteria.getFirmwareVersion(), copy.getFirmwareVersion()) &&
                condition.apply(criteria.getFileName(), copy.getFileName()) &&
                condition.apply(criteria.getDeviceId(), copy.getDeviceId()) &&
                condition.apply(criteria.getDateTime(), copy.getDateTime()) &&
                condition.apply(criteria.getCustomerId(), copy.getCustomerId()) &&
                condition.apply(criteria.getGroupID(), copy.getGroupID()) &&
                condition.apply(criteria.getDistinct(), copy.getDistinct()),
            "every filter matches"
        );
    }
}
