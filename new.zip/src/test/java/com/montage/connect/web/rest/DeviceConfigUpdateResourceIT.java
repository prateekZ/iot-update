package com.montage.connect.web.rest;

import static com.montage.connect.domain.DeviceConfigUpdateAsserts.*;
import static com.montage.connect.web.rest.TestUtil.createUpdateProxyForBean;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.montage.connect.IntegrationTest;
import com.montage.connect.domain.DeviceConfigUpdate;
import com.montage.connect.repository.DeviceConfigUpdateRepository;
import com.montage.connect.service.dto.DeviceConfigUpdateDTO;
import com.montage.connect.service.mapper.DeviceConfigUpdateMapper;
import jakarta.persistence.EntityManager;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link DeviceConfigUpdateResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class DeviceConfigUpdateResourceIT {

    private static final String DEFAULT_CONFIG_VERSION = "AAAAAAAAAA";
    private static final String UPDATED_CONFIG_VERSION = "BBBBBBBBBB";

    private static final String DEFAULT_FIRMWARE_VERSION = "AAAAAAAAAA";
    private static final String UPDATED_FIRMWARE_VERSION = "BBBBBBBBBB";

    private static final String DEFAULT_FILE_NAME = "AAAAAAAAAA";
    private static final String UPDATED_FILE_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_DEVICE_ID = "AAAAAAAAAA";
    private static final String UPDATED_DEVICE_ID = "BBBBBBBBBB";

    private static final byte[] DEFAULT_BINARY_FILE = TestUtil.createByteArray(1, "0");
    private static final byte[] UPDATED_BINARY_FILE = TestUtil.createByteArray(1, "1");
    private static final String DEFAULT_BINARY_FILE_CONTENT_TYPE = "image/jpg";
    private static final String UPDATED_BINARY_FILE_CONTENT_TYPE = "image/png";

    private static final Instant DEFAULT_DATE_TIME = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_DATE_TIME = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final String DEFAULT_CUSTOMER_ID = "AAAAAAAAAA";
    private static final String UPDATED_CUSTOMER_ID = "BBBBBBBBBB";

    private static final String DEFAULT_GROUP_ID = "AAAAAAAAAA";
    private static final String UPDATED_GROUP_ID = "BBBBBBBBBB";

    private static final String ENTITY_API_URL = "/api/device-config-updates";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private ObjectMapper om;

    @Autowired
    private DeviceConfigUpdateRepository deviceConfigUpdateRepository;

    @Autowired
    private DeviceConfigUpdateMapper deviceConfigUpdateMapper;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restDeviceConfigUpdateMockMvc;

    private DeviceConfigUpdate deviceConfigUpdate;

    private DeviceConfigUpdate insertedDeviceConfigUpdate;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static DeviceConfigUpdate createEntity(EntityManager em) {
        DeviceConfigUpdate deviceConfigUpdate = new DeviceConfigUpdate()
            .configVersion(DEFAULT_CONFIG_VERSION)
            .firmwareVersion(DEFAULT_FIRMWARE_VERSION)
            .fileName(DEFAULT_FILE_NAME)
            .deviceId(DEFAULT_DEVICE_ID)
            .binaryFile(DEFAULT_BINARY_FILE)
            .binaryFileContentType(DEFAULT_BINARY_FILE_CONTENT_TYPE)
            .dateTime(DEFAULT_DATE_TIME)
            .customerId(DEFAULT_CUSTOMER_ID)
            .groupID(DEFAULT_GROUP_ID);
        return deviceConfigUpdate;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static DeviceConfigUpdate createUpdatedEntity(EntityManager em) {
        DeviceConfigUpdate deviceConfigUpdate = new DeviceConfigUpdate()
            .configVersion(UPDATED_CONFIG_VERSION)
            .firmwareVersion(UPDATED_FIRMWARE_VERSION)
            .fileName(UPDATED_FILE_NAME)
            .deviceId(UPDATED_DEVICE_ID)
            .binaryFile(UPDATED_BINARY_FILE)
            .binaryFileContentType(UPDATED_BINARY_FILE_CONTENT_TYPE)
            .dateTime(UPDATED_DATE_TIME)
            .customerId(UPDATED_CUSTOMER_ID)
            .groupID(UPDATED_GROUP_ID);
        return deviceConfigUpdate;
    }

    @BeforeEach
    public void initTest() {
        deviceConfigUpdate = createEntity(em);
    }

    @AfterEach
    public void cleanup() {
        if (insertedDeviceConfigUpdate != null) {
            deviceConfigUpdateRepository.delete(insertedDeviceConfigUpdate);
            insertedDeviceConfigUpdate = null;
        }
    }

    @Test
    @Transactional
    void createDeviceConfigUpdate() throws Exception {
        long databaseSizeBeforeCreate = getRepositoryCount();
        // Create the DeviceConfigUpdate
        DeviceConfigUpdateDTO deviceConfigUpdateDTO = deviceConfigUpdateMapper.toDto(deviceConfigUpdate);
        var returnedDeviceConfigUpdateDTO = om.readValue(
            restDeviceConfigUpdateMockMvc
                .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(om.writeValueAsBytes(deviceConfigUpdateDTO)))
                .andExpect(status().isCreated())
                .andReturn()
                .getResponse()
                .getContentAsString(),
            DeviceConfigUpdateDTO.class
        );

        // Validate the DeviceConfigUpdate in the database
        assertIncrementedRepositoryCount(databaseSizeBeforeCreate);
        var returnedDeviceConfigUpdate = deviceConfigUpdateMapper.toEntity(returnedDeviceConfigUpdateDTO);
        assertDeviceConfigUpdateUpdatableFieldsEquals(
            returnedDeviceConfigUpdate,
            getPersistedDeviceConfigUpdate(returnedDeviceConfigUpdate)
        );

        insertedDeviceConfigUpdate = returnedDeviceConfigUpdate;
    }

    @Test
    @Transactional
    void createDeviceConfigUpdateWithExistingId() throws Exception {
        // Create the DeviceConfigUpdate with an existing ID
        deviceConfigUpdate.setId(1L);
        DeviceConfigUpdateDTO deviceConfigUpdateDTO = deviceConfigUpdateMapper.toDto(deviceConfigUpdate);

        long databaseSizeBeforeCreate = getRepositoryCount();

        // An entity with an existing ID cannot be created, so this API call must fail
        restDeviceConfigUpdateMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(om.writeValueAsBytes(deviceConfigUpdateDTO)))
            .andExpect(status().isBadRequest());

        // Validate the DeviceConfigUpdate in the database
        assertSameRepositoryCount(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdates() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList
        restDeviceConfigUpdateMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(deviceConfigUpdate.getId().intValue())))
            .andExpect(jsonPath("$.[*].configVersion").value(hasItem(DEFAULT_CONFIG_VERSION)))
            .andExpect(jsonPath("$.[*].firmwareVersion").value(hasItem(DEFAULT_FIRMWARE_VERSION)))
            .andExpect(jsonPath("$.[*].fileName").value(hasItem(DEFAULT_FILE_NAME)))
            .andExpect(jsonPath("$.[*].deviceId").value(hasItem(DEFAULT_DEVICE_ID)))
            .andExpect(jsonPath("$.[*].binaryFileContentType").value(hasItem(DEFAULT_BINARY_FILE_CONTENT_TYPE)))
            .andExpect(jsonPath("$.[*].binaryFile").value(hasItem(Base64.getEncoder().encodeToString(DEFAULT_BINARY_FILE))))
            .andExpect(jsonPath("$.[*].dateTime").value(hasItem(DEFAULT_DATE_TIME.toString())))
            .andExpect(jsonPath("$.[*].customerId").value(hasItem(DEFAULT_CUSTOMER_ID)))
            .andExpect(jsonPath("$.[*].groupID").value(hasItem(DEFAULT_GROUP_ID)));
    }

    @Test
    @Transactional
    void getDeviceConfigUpdate() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get the deviceConfigUpdate
        restDeviceConfigUpdateMockMvc
            .perform(get(ENTITY_API_URL_ID, deviceConfigUpdate.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(deviceConfigUpdate.getId().intValue()))
            .andExpect(jsonPath("$.configVersion").value(DEFAULT_CONFIG_VERSION))
            .andExpect(jsonPath("$.firmwareVersion").value(DEFAULT_FIRMWARE_VERSION))
            .andExpect(jsonPath("$.fileName").value(DEFAULT_FILE_NAME))
            .andExpect(jsonPath("$.deviceId").value(DEFAULT_DEVICE_ID))
            .andExpect(jsonPath("$.binaryFileContentType").value(DEFAULT_BINARY_FILE_CONTENT_TYPE))
            .andExpect(jsonPath("$.binaryFile").value(Base64.getEncoder().encodeToString(DEFAULT_BINARY_FILE)))
            .andExpect(jsonPath("$.dateTime").value(DEFAULT_DATE_TIME.toString()))
            .andExpect(jsonPath("$.customerId").value(DEFAULT_CUSTOMER_ID))
            .andExpect(jsonPath("$.groupID").value(DEFAULT_GROUP_ID));
    }

    @Test
    @Transactional
    void getDeviceConfigUpdatesByIdFiltering() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        Long id = deviceConfigUpdate.getId();

        defaultDeviceConfigUpdateFiltering("id.equals=" + id, "id.notEquals=" + id);

        defaultDeviceConfigUpdateFiltering("id.greaterThanOrEqual=" + id, "id.greaterThan=" + id);

        defaultDeviceConfigUpdateFiltering("id.lessThanOrEqual=" + id, "id.lessThan=" + id);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByConfigVersionIsEqualToSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where configVersion equals to
        defaultDeviceConfigUpdateFiltering(
            "configVersion.equals=" + DEFAULT_CONFIG_VERSION,
            "configVersion.equals=" + UPDATED_CONFIG_VERSION
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByConfigVersionIsInShouldWork() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where configVersion in
        defaultDeviceConfigUpdateFiltering(
            "configVersion.in=" + DEFAULT_CONFIG_VERSION + "," + UPDATED_CONFIG_VERSION,
            "configVersion.in=" + UPDATED_CONFIG_VERSION
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByConfigVersionIsNullOrNotNull() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where configVersion is not null
        defaultDeviceConfigUpdateFiltering("configVersion.specified=true", "configVersion.specified=false");
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByConfigVersionContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where configVersion contains
        defaultDeviceConfigUpdateFiltering(
            "configVersion.contains=" + DEFAULT_CONFIG_VERSION,
            "configVersion.contains=" + UPDATED_CONFIG_VERSION
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByConfigVersionNotContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where configVersion does not contain
        defaultDeviceConfigUpdateFiltering(
            "configVersion.doesNotContain=" + UPDATED_CONFIG_VERSION,
            "configVersion.doesNotContain=" + DEFAULT_CONFIG_VERSION
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByFirmwareVersionIsEqualToSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where firmwareVersion equals to
        defaultDeviceConfigUpdateFiltering(
            "firmwareVersion.equals=" + DEFAULT_FIRMWARE_VERSION,
            "firmwareVersion.equals=" + UPDATED_FIRMWARE_VERSION
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByFirmwareVersionIsInShouldWork() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where firmwareVersion in
        defaultDeviceConfigUpdateFiltering(
            "firmwareVersion.in=" + DEFAULT_FIRMWARE_VERSION + "," + UPDATED_FIRMWARE_VERSION,
            "firmwareVersion.in=" + UPDATED_FIRMWARE_VERSION
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByFirmwareVersionIsNullOrNotNull() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where firmwareVersion is not null
        defaultDeviceConfigUpdateFiltering("firmwareVersion.specified=true", "firmwareVersion.specified=false");
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByFirmwareVersionContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where firmwareVersion contains
        defaultDeviceConfigUpdateFiltering(
            "firmwareVersion.contains=" + DEFAULT_FIRMWARE_VERSION,
            "firmwareVersion.contains=" + UPDATED_FIRMWARE_VERSION
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByFirmwareVersionNotContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where firmwareVersion does not contain
        defaultDeviceConfigUpdateFiltering(
            "firmwareVersion.doesNotContain=" + UPDATED_FIRMWARE_VERSION,
            "firmwareVersion.doesNotContain=" + DEFAULT_FIRMWARE_VERSION
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByFileNameIsEqualToSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where fileName equals to
        defaultDeviceConfigUpdateFiltering("fileName.equals=" + DEFAULT_FILE_NAME, "fileName.equals=" + UPDATED_FILE_NAME);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByFileNameIsInShouldWork() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where fileName in
        defaultDeviceConfigUpdateFiltering(
            "fileName.in=" + DEFAULT_FILE_NAME + "," + UPDATED_FILE_NAME,
            "fileName.in=" + UPDATED_FILE_NAME
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByFileNameIsNullOrNotNull() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where fileName is not null
        defaultDeviceConfigUpdateFiltering("fileName.specified=true", "fileName.specified=false");
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByFileNameContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where fileName contains
        defaultDeviceConfigUpdateFiltering("fileName.contains=" + DEFAULT_FILE_NAME, "fileName.contains=" + UPDATED_FILE_NAME);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByFileNameNotContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where fileName does not contain
        defaultDeviceConfigUpdateFiltering("fileName.doesNotContain=" + UPDATED_FILE_NAME, "fileName.doesNotContain=" + DEFAULT_FILE_NAME);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByDeviceIdIsEqualToSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where deviceId equals to
        defaultDeviceConfigUpdateFiltering("deviceId.equals=" + DEFAULT_DEVICE_ID, "deviceId.equals=" + UPDATED_DEVICE_ID);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByDeviceIdIsInShouldWork() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where deviceId in
        defaultDeviceConfigUpdateFiltering(
            "deviceId.in=" + DEFAULT_DEVICE_ID + "," + UPDATED_DEVICE_ID,
            "deviceId.in=" + UPDATED_DEVICE_ID
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByDeviceIdIsNullOrNotNull() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where deviceId is not null
        defaultDeviceConfigUpdateFiltering("deviceId.specified=true", "deviceId.specified=false");
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByDeviceIdContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where deviceId contains
        defaultDeviceConfigUpdateFiltering("deviceId.contains=" + DEFAULT_DEVICE_ID, "deviceId.contains=" + UPDATED_DEVICE_ID);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByDeviceIdNotContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where deviceId does not contain
        defaultDeviceConfigUpdateFiltering("deviceId.doesNotContain=" + UPDATED_DEVICE_ID, "deviceId.doesNotContain=" + DEFAULT_DEVICE_ID);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByDateTimeIsEqualToSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where dateTime equals to
        defaultDeviceConfigUpdateFiltering("dateTime.equals=" + DEFAULT_DATE_TIME, "dateTime.equals=" + UPDATED_DATE_TIME);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByDateTimeIsInShouldWork() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where dateTime in
        defaultDeviceConfigUpdateFiltering(
            "dateTime.in=" + DEFAULT_DATE_TIME + "," + UPDATED_DATE_TIME,
            "dateTime.in=" + UPDATED_DATE_TIME
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByDateTimeIsNullOrNotNull() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where dateTime is not null
        defaultDeviceConfigUpdateFiltering("dateTime.specified=true", "dateTime.specified=false");
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByCustomerIdIsEqualToSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where customerId equals to
        defaultDeviceConfigUpdateFiltering("customerId.equals=" + DEFAULT_CUSTOMER_ID, "customerId.equals=" + UPDATED_CUSTOMER_ID);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByCustomerIdIsInShouldWork() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where customerId in
        defaultDeviceConfigUpdateFiltering(
            "customerId.in=" + DEFAULT_CUSTOMER_ID + "," + UPDATED_CUSTOMER_ID,
            "customerId.in=" + UPDATED_CUSTOMER_ID
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByCustomerIdIsNullOrNotNull() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where customerId is not null
        defaultDeviceConfigUpdateFiltering("customerId.specified=true", "customerId.specified=false");
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByCustomerIdContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where customerId contains
        defaultDeviceConfigUpdateFiltering("customerId.contains=" + DEFAULT_CUSTOMER_ID, "customerId.contains=" + UPDATED_CUSTOMER_ID);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByCustomerIdNotContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where customerId does not contain
        defaultDeviceConfigUpdateFiltering(
            "customerId.doesNotContain=" + UPDATED_CUSTOMER_ID,
            "customerId.doesNotContain=" + DEFAULT_CUSTOMER_ID
        );
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByGroupIDIsEqualToSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where groupID equals to
        defaultDeviceConfigUpdateFiltering("groupID.equals=" + DEFAULT_GROUP_ID, "groupID.equals=" + UPDATED_GROUP_ID);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByGroupIDIsInShouldWork() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where groupID in
        defaultDeviceConfigUpdateFiltering("groupID.in=" + DEFAULT_GROUP_ID + "," + UPDATED_GROUP_ID, "groupID.in=" + UPDATED_GROUP_ID);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByGroupIDIsNullOrNotNull() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where groupID is not null
        defaultDeviceConfigUpdateFiltering("groupID.specified=true", "groupID.specified=false");
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByGroupIDContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where groupID contains
        defaultDeviceConfigUpdateFiltering("groupID.contains=" + DEFAULT_GROUP_ID, "groupID.contains=" + UPDATED_GROUP_ID);
    }

    @Test
    @Transactional
    void getAllDeviceConfigUpdatesByGroupIDNotContainsSomething() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        // Get all the deviceConfigUpdateList where groupID does not contain
        defaultDeviceConfigUpdateFiltering("groupID.doesNotContain=" + UPDATED_GROUP_ID, "groupID.doesNotContain=" + DEFAULT_GROUP_ID);
    }

    private void defaultDeviceConfigUpdateFiltering(String shouldBeFound, String shouldNotBeFound) throws Exception {
        defaultDeviceConfigUpdateShouldBeFound(shouldBeFound);
        defaultDeviceConfigUpdateShouldNotBeFound(shouldNotBeFound);
    }

    /**
     * Executes the search, and checks that the default entity is returned.
     */
    private void defaultDeviceConfigUpdateShouldBeFound(String filter) throws Exception {
        restDeviceConfigUpdateMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(deviceConfigUpdate.getId().intValue())))
            .andExpect(jsonPath("$.[*].configVersion").value(hasItem(DEFAULT_CONFIG_VERSION)))
            .andExpect(jsonPath("$.[*].firmwareVersion").value(hasItem(DEFAULT_FIRMWARE_VERSION)))
            .andExpect(jsonPath("$.[*].fileName").value(hasItem(DEFAULT_FILE_NAME)))
            .andExpect(jsonPath("$.[*].deviceId").value(hasItem(DEFAULT_DEVICE_ID)))
            .andExpect(jsonPath("$.[*].binaryFileContentType").value(hasItem(DEFAULT_BINARY_FILE_CONTENT_TYPE)))
            .andExpect(jsonPath("$.[*].binaryFile").value(hasItem(Base64.getEncoder().encodeToString(DEFAULT_BINARY_FILE))))
            .andExpect(jsonPath("$.[*].dateTime").value(hasItem(DEFAULT_DATE_TIME.toString())))
            .andExpect(jsonPath("$.[*].customerId").value(hasItem(DEFAULT_CUSTOMER_ID)))
            .andExpect(jsonPath("$.[*].groupID").value(hasItem(DEFAULT_GROUP_ID)));

        // Check, that the count call also returns 1
        restDeviceConfigUpdateMockMvc
            .perform(get(ENTITY_API_URL + "/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(content().string("1"));
    }

    /**
     * Executes the search, and checks that the default entity is not returned.
     */
    private void defaultDeviceConfigUpdateShouldNotBeFound(String filter) throws Exception {
        restDeviceConfigUpdateMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$").isEmpty());

        // Check, that the count call also returns 0
        restDeviceConfigUpdateMockMvc
            .perform(get(ENTITY_API_URL + "/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(content().string("0"));
    }

    @Test
    @Transactional
    void getNonExistingDeviceConfigUpdate() throws Exception {
        // Get the deviceConfigUpdate
        restDeviceConfigUpdateMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingDeviceConfigUpdate() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        long databaseSizeBeforeUpdate = getRepositoryCount();

        // Update the deviceConfigUpdate
        DeviceConfigUpdate updatedDeviceConfigUpdate = deviceConfigUpdateRepository.findById(deviceConfigUpdate.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedDeviceConfigUpdate are not directly saved in db
        em.detach(updatedDeviceConfigUpdate);
        updatedDeviceConfigUpdate
            .configVersion(UPDATED_CONFIG_VERSION)
            .firmwareVersion(UPDATED_FIRMWARE_VERSION)
            .fileName(UPDATED_FILE_NAME)
            .deviceId(UPDATED_DEVICE_ID)
            .binaryFile(UPDATED_BINARY_FILE)
            .binaryFileContentType(UPDATED_BINARY_FILE_CONTENT_TYPE)
            .dateTime(UPDATED_DATE_TIME)
            .customerId(UPDATED_CUSTOMER_ID)
            .groupID(UPDATED_GROUP_ID);
        DeviceConfigUpdateDTO deviceConfigUpdateDTO = deviceConfigUpdateMapper.toDto(updatedDeviceConfigUpdate);

        restDeviceConfigUpdateMockMvc
            .perform(
                put(ENTITY_API_URL_ID, deviceConfigUpdateDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(om.writeValueAsBytes(deviceConfigUpdateDTO))
            )
            .andExpect(status().isOk());

        // Validate the DeviceConfigUpdate in the database
        assertSameRepositoryCount(databaseSizeBeforeUpdate);
        assertPersistedDeviceConfigUpdateToMatchAllProperties(updatedDeviceConfigUpdate);
    }

    @Test
    @Transactional
    void putNonExistingDeviceConfigUpdate() throws Exception {
        long databaseSizeBeforeUpdate = getRepositoryCount();
        deviceConfigUpdate.setId(longCount.incrementAndGet());

        // Create the DeviceConfigUpdate
        DeviceConfigUpdateDTO deviceConfigUpdateDTO = deviceConfigUpdateMapper.toDto(deviceConfigUpdate);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restDeviceConfigUpdateMockMvc
            .perform(
                put(ENTITY_API_URL_ID, deviceConfigUpdateDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(om.writeValueAsBytes(deviceConfigUpdateDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the DeviceConfigUpdate in the database
        assertSameRepositoryCount(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchDeviceConfigUpdate() throws Exception {
        long databaseSizeBeforeUpdate = getRepositoryCount();
        deviceConfigUpdate.setId(longCount.incrementAndGet());

        // Create the DeviceConfigUpdate
        DeviceConfigUpdateDTO deviceConfigUpdateDTO = deviceConfigUpdateMapper.toDto(deviceConfigUpdate);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restDeviceConfigUpdateMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(om.writeValueAsBytes(deviceConfigUpdateDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the DeviceConfigUpdate in the database
        assertSameRepositoryCount(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamDeviceConfigUpdate() throws Exception {
        long databaseSizeBeforeUpdate = getRepositoryCount();
        deviceConfigUpdate.setId(longCount.incrementAndGet());

        // Create the DeviceConfigUpdate
        DeviceConfigUpdateDTO deviceConfigUpdateDTO = deviceConfigUpdateMapper.toDto(deviceConfigUpdate);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restDeviceConfigUpdateMockMvc
            .perform(put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(om.writeValueAsBytes(deviceConfigUpdateDTO)))
            .andExpect(status().isMethodNotAllowed());

        // Validate the DeviceConfigUpdate in the database
        assertSameRepositoryCount(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateDeviceConfigUpdateWithPatch() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        long databaseSizeBeforeUpdate = getRepositoryCount();

        // Update the deviceConfigUpdate using partial update
        DeviceConfigUpdate partialUpdatedDeviceConfigUpdate = new DeviceConfigUpdate();
        partialUpdatedDeviceConfigUpdate.setId(deviceConfigUpdate.getId());

        partialUpdatedDeviceConfigUpdate
            .firmwareVersion(UPDATED_FIRMWARE_VERSION)
            .deviceId(UPDATED_DEVICE_ID)
            .binaryFile(UPDATED_BINARY_FILE)
            .binaryFileContentType(UPDATED_BINARY_FILE_CONTENT_TYPE)
            .customerId(UPDATED_CUSTOMER_ID)
            .groupID(UPDATED_GROUP_ID);

        restDeviceConfigUpdateMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedDeviceConfigUpdate.getId())
                    .contentType("application/merge-patch+json")
                    .content(om.writeValueAsBytes(partialUpdatedDeviceConfigUpdate))
            )
            .andExpect(status().isOk());

        // Validate the DeviceConfigUpdate in the database

        assertSameRepositoryCount(databaseSizeBeforeUpdate);
        assertDeviceConfigUpdateUpdatableFieldsEquals(
            createUpdateProxyForBean(partialUpdatedDeviceConfigUpdate, deviceConfigUpdate),
            getPersistedDeviceConfigUpdate(deviceConfigUpdate)
        );
    }

    @Test
    @Transactional
    void fullUpdateDeviceConfigUpdateWithPatch() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        long databaseSizeBeforeUpdate = getRepositoryCount();

        // Update the deviceConfigUpdate using partial update
        DeviceConfigUpdate partialUpdatedDeviceConfigUpdate = new DeviceConfigUpdate();
        partialUpdatedDeviceConfigUpdate.setId(deviceConfigUpdate.getId());

        partialUpdatedDeviceConfigUpdate
            .configVersion(UPDATED_CONFIG_VERSION)
            .firmwareVersion(UPDATED_FIRMWARE_VERSION)
            .fileName(UPDATED_FILE_NAME)
            .deviceId(UPDATED_DEVICE_ID)
            .binaryFile(UPDATED_BINARY_FILE)
            .binaryFileContentType(UPDATED_BINARY_FILE_CONTENT_TYPE)
            .dateTime(UPDATED_DATE_TIME)
            .customerId(UPDATED_CUSTOMER_ID)
            .groupID(UPDATED_GROUP_ID);

        restDeviceConfigUpdateMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedDeviceConfigUpdate.getId())
                    .contentType("application/merge-patch+json")
                    .content(om.writeValueAsBytes(partialUpdatedDeviceConfigUpdate))
            )
            .andExpect(status().isOk());

        // Validate the DeviceConfigUpdate in the database

        assertSameRepositoryCount(databaseSizeBeforeUpdate);
        assertDeviceConfigUpdateUpdatableFieldsEquals(
            partialUpdatedDeviceConfigUpdate,
            getPersistedDeviceConfigUpdate(partialUpdatedDeviceConfigUpdate)
        );
    }

    @Test
    @Transactional
    void patchNonExistingDeviceConfigUpdate() throws Exception {
        long databaseSizeBeforeUpdate = getRepositoryCount();
        deviceConfigUpdate.setId(longCount.incrementAndGet());

        // Create the DeviceConfigUpdate
        DeviceConfigUpdateDTO deviceConfigUpdateDTO = deviceConfigUpdateMapper.toDto(deviceConfigUpdate);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restDeviceConfigUpdateMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, deviceConfigUpdateDTO.getId())
                    .contentType("application/merge-patch+json")
                    .content(om.writeValueAsBytes(deviceConfigUpdateDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the DeviceConfigUpdate in the database
        assertSameRepositoryCount(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchDeviceConfigUpdate() throws Exception {
        long databaseSizeBeforeUpdate = getRepositoryCount();
        deviceConfigUpdate.setId(longCount.incrementAndGet());

        // Create the DeviceConfigUpdate
        DeviceConfigUpdateDTO deviceConfigUpdateDTO = deviceConfigUpdateMapper.toDto(deviceConfigUpdate);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restDeviceConfigUpdateMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(om.writeValueAsBytes(deviceConfigUpdateDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the DeviceConfigUpdate in the database
        assertSameRepositoryCount(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamDeviceConfigUpdate() throws Exception {
        long databaseSizeBeforeUpdate = getRepositoryCount();
        deviceConfigUpdate.setId(longCount.incrementAndGet());

        // Create the DeviceConfigUpdate
        DeviceConfigUpdateDTO deviceConfigUpdateDTO = deviceConfigUpdateMapper.toDto(deviceConfigUpdate);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restDeviceConfigUpdateMockMvc
            .perform(patch(ENTITY_API_URL).contentType("application/merge-patch+json").content(om.writeValueAsBytes(deviceConfigUpdateDTO)))
            .andExpect(status().isMethodNotAllowed());

        // Validate the DeviceConfigUpdate in the database
        assertSameRepositoryCount(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteDeviceConfigUpdate() throws Exception {
        // Initialize the database
        insertedDeviceConfigUpdate = deviceConfigUpdateRepository.saveAndFlush(deviceConfigUpdate);

        long databaseSizeBeforeDelete = getRepositoryCount();

        // Delete the deviceConfigUpdate
        restDeviceConfigUpdateMockMvc
            .perform(delete(ENTITY_API_URL_ID, deviceConfigUpdate.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        assertDecrementedRepositoryCount(databaseSizeBeforeDelete);
    }

    protected long getRepositoryCount() {
        return deviceConfigUpdateRepository.count();
    }

    protected void assertIncrementedRepositoryCount(long countBefore) {
        assertThat(countBefore + 1).isEqualTo(getRepositoryCount());
    }

    protected void assertDecrementedRepositoryCount(long countBefore) {
        assertThat(countBefore - 1).isEqualTo(getRepositoryCount());
    }

    protected void assertSameRepositoryCount(long countBefore) {
        assertThat(countBefore).isEqualTo(getRepositoryCount());
    }

    protected DeviceConfigUpdate getPersistedDeviceConfigUpdate(DeviceConfigUpdate deviceConfigUpdate) {
        return deviceConfigUpdateRepository.findById(deviceConfigUpdate.getId()).orElseThrow();
    }

    protected void assertPersistedDeviceConfigUpdateToMatchAllProperties(DeviceConfigUpdate expectedDeviceConfigUpdate) {
        assertDeviceConfigUpdateAllPropertiesEquals(expectedDeviceConfigUpdate, getPersistedDeviceConfigUpdate(expectedDeviceConfigUpdate));
    }

    protected void assertPersistedDeviceConfigUpdateToMatchUpdatableProperties(DeviceConfigUpdate expectedDeviceConfigUpdate) {
        assertDeviceConfigUpdateAllUpdatablePropertiesEquals(
            expectedDeviceConfigUpdate,
            getPersistedDeviceConfigUpdate(expectedDeviceConfigUpdate)
        );
    }
}
