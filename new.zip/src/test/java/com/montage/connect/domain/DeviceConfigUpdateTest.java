package com.montage.connect.domain;

import static com.montage.connect.domain.DeviceConfigUpdateTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.montage.connect.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class DeviceConfigUpdateTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(DeviceConfigUpdate.class);
        DeviceConfigUpdate deviceConfigUpdate1 = getDeviceConfigUpdateSample1();
        DeviceConfigUpdate deviceConfigUpdate2 = new DeviceConfigUpdate();
        assertThat(deviceConfigUpdate1).isNotEqualTo(deviceConfigUpdate2);

        deviceConfigUpdate2.setId(deviceConfigUpdate1.getId());
        assertThat(deviceConfigUpdate1).isEqualTo(deviceConfigUpdate2);

        deviceConfigUpdate2 = getDeviceConfigUpdateSample2();
        assertThat(deviceConfigUpdate1).isNotEqualTo(deviceConfigUpdate2);
    }
}
