package com.montage.connect.domain;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class DeviceConfigUpdateTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static DeviceConfigUpdate getDeviceConfigUpdateSample1() {
        return new DeviceConfigUpdate()
            .id(1L)
            .configVersion("configVersion1")
            .firmwareVersion("firmwareVersion1")
            .fileName("fileName1")
            .deviceId("deviceId1")
            .customerId("customerId1")
            .groupID("groupID1");
    }

    public static DeviceConfigUpdate getDeviceConfigUpdateSample2() {
        return new DeviceConfigUpdate()
            .id(2L)
            .configVersion("configVersion2")
            .firmwareVersion("firmwareVersion2")
            .fileName("fileName2")
            .deviceId("deviceId2")
            .customerId("customerId2")
            .groupID("groupID2");
    }

    public static DeviceConfigUpdate getDeviceConfigUpdateRandomSampleGenerator() {
        return new DeviceConfigUpdate()
            .id(longCount.incrementAndGet())
            .configVersion(UUID.randomUUID().toString())
            .firmwareVersion(UUID.randomUUID().toString())
            .fileName(UUID.randomUUID().toString())
            .deviceId(UUID.randomUUID().toString())
            .customerId(UUID.randomUUID().toString())
            .groupID(UUID.randomUUID().toString());
    }
}
